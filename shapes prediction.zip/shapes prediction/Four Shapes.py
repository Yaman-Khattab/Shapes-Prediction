import numpy as np # linear algebra
import pandas as pd # data processing, CSV file I/O (e.g. pd.read_csv)
from random import shuffle

from os import listdir
from tqdm import tqdm
from os.path import join
import cv2

# Input data files are available in the read-only "../input/" directory
# For example, running this (by clicking run or pressing Shift+Enter) will list all files under the input directory
import os


dataInput = "../input/four-shapes/shapes/train/"

shapes = ["circle","square","star","triangle"]
data = []#IMG_DATA
X = []
Y = []






# move on every shape(circle,star,etc..) and Resize the Image.
def preprocess():
    for i in (shapes):
        for img in tqdm(listdir(join(dataInput,i))):
            imgData=cv2.resize(cv2.imread(join(dataInput,i,img),cv2.IMREAD_GRAYSCALE),(100,100))
            data.append([imgData,i])            
preprocess()






# Change the Order of the Images
shuffle(data)

for feature, label in data:
    X.append(feature)
    Y.append(label)
    
for i in range(len(Y)):
    Y[i]=shapes.index(Y[i])

#Creating Arrays  
X=np.array(X)
Y=np.array(Y)
X=X.reshape(-1,100,100,1)

X=X/np.float32(255)









# Stack Layers Sequentially
model = Sequential()

# Input_shape = 100 * 100 * 1 = 10,000 Elements
# relu function returns 0 if it receives any negative input, but for any positive value, it returns that value back.
# Max pooling will reduce the size of the image by taking the maximium values
# Stride of the filter is default (1,1)

model.add(Conv2D(64,(3,3),activation = "relu", input_shape = (100,100,1)))
model.add(MaxPooling2D((2,2)))
model.add(Conv2D(64,(3,3),activation = "relu" ))
model.add(MaxPooling2D((2,2)))

# Flatten used to Covert list of Arrays into one array
# Random neurons are ignored during training

# SoftMax Activation function: the winner takes all activation model in which the unit with the largest input has output +1 while all other units have output 0.
# relu function returns 0 if it receives any negative input, but for any positive value, it returns that value back.
# Sigmoid Activation Function used for models where we have to predict the probablility and it will be between 0 or 1 

model.add(Flatten())
model.add(Dense(256, activation = 'sigmoid'))
model.add(Dropout(0.2))
model.add(Dense(256, activation='sigmoid'))
model.add(Dropout(0.2))
model.add(Dense(256, activation='relu'))
model.add(Dropout(0.2))
model.add(Dense(4, activation='softmax'))

# Batch size is the number of samples to work through before updating the internal model parameters.
# Epochs is the number of times that the learning algorithm will work through the entire training dataset.
# validation_split: split your data in 80% train & 20% test
model.compile(optimizer='adam', loss='sparse_categorical_crossentropy', metrics=['accuracy'])
model.fit(X,Y, batch_size = 256, epochs=5,validation_split=0.2)








model.save("four-shape-model")

from tensorflow.keras.models import load_model
import matplotlib.pyplot as plt

new = load_model("four-shape-model")



testImgs = "../input/four-shapes/shapes/test/" 

data2 = []
        
for i in (shapes):
        for img in tqdm(listdir(join(testImgs,i))):
            imgData=cv2.resize(cv2.imread(join(testImgs,i,img),cv2.IMREAD_GRAYSCALE),(100,100))
            data2.append(imgData)

shuffle(data2)

# Predicting 50 Random Images
for i in range(50):
    
    plt.imshow(data2[i],cmap="gray")
    plt.show()
    data2[i]=data2[i].reshape(1,100,100,1)
    data2[i].shape 
    
    #predict() function enables us to predict the labels of the data values on the basis of the trained model.
    pred=new.predict(data2[i])
    
    #Printing The Label of the predicted Image
    print(shapes[np.argmax(pred)])

